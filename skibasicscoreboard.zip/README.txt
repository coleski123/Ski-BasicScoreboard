The only thing I ask is for you to join my discord

https://discord.gg/at8yqRQ