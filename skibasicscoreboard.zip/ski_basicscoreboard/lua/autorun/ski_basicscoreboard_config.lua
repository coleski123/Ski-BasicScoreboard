skibasicscoreboard = skibasicscoreboard or {}
skibasicscoreboard.config = {}


skibasicscoreboard.config.ServerName = "SkiGangNetworks" --Server name

skibasicscoreboard.config.currency = "$" --Currency

skibasicscoreboard.config.ServerLogo = "https://i.imgur.com/xHihgpC.png" --74x74 imgur image. Make sure imgur is public and has .png or .jpg extension


--ULX rank names/colors
skibasicscoreboard.config.ranks = {
    [ 'superadmin' ] = { name = 'Super Administrator', color = Color( 199, 44, 44 ) },
    [ 'admin' ] = { name = 'Administrator', color = Color( 199, 44, 44 ) },
    [ 'moderator' ] = { name = 'Moderator', color = Color( 1, 203, 218 ) },
    [ 'developer' ] = { name = 'Developer', color = Color( 199, 44, 44 ) },
    [ 'vip' ] = { name = 'VIP', color = Color( 155, 89, 182 ) }
}