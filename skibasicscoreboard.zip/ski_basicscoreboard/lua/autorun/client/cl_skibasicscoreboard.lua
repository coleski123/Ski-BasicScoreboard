AddCSLuaFile("ski_basicscoreboard_config.lua")

--Initial Start
function ToggleScoreboard(toggle)
	if toggle then

		local scrw,scrh = ScrW(), ScrH()
		SkiBasicScoreboardUI = vgui.Create("DFrame")
		SkiBasicScoreboardUI:SetTitle("")
		SkiBasicScoreboardUI:SetSize(900,800)
		SkiBasicScoreboardUI:Center()
		SkiBasicScoreboardUI:MakePopup()
		SkiBasicScoreboardUI:ShowCloseButton(false)
		SkiBasicScoreboardUI:SetDraggable(false)
		SkiBasicScoreboardUI:SetVisible( true )
        SkiBasicScoreboardUI.Paint = function(s,w,h)

        local BGColor = Color(0,0,0,200)
	    draw.RoundedBox( 20, 0, 0, 900, 800, BGColor )

        local topbar = Color(255,255,255)
        draw.RoundedBox( 0, 0, 100, 900, 5, topbar )

        local ServerName = skibasicscoreboard.config.ServerName
		draw.SimpleText( ServerName, "ServerName", 450, 20, color_white, TEXT_ALIGN_CENTER)

		draw.SimpleText("Name", "Categories", 133,134, color_white, TEXT_ALIGN_CENTER)
		draw.SimpleText("Job", "Categories", 315,134, color_white, TEXT_ALIGN_CENTER)
		draw.SimpleText("Rank", "Categories", 530,134, color_white, TEXT_ALIGN_CENTER)
		draw.SimpleText("Money", "Categories", 725,134, color_white, TEXT_ALIGN_CENTER)
		draw.SimpleText("Ping", "Categories", 825,134, color_white, TEXT_ALIGN_CENTER)

		draw.SimpleText( #player.GetAll() == 1 and 'There is currently 1 player online.' or 'There are currently ' .. #player.GetAll() .. " players online.", "PlayersOnline", 450,75, Color( 70, 135, 255 ), TEXT_ALIGN_CENTER )

        end

		--ScrollPanel
		local scroll = vgui.Create("DScrollPanel", SkiBasicScoreboardUI)
		scroll:SetPos(-35,156)
		scroll:SetSize(SkiBasicScoreboardUI:GetWide(), SkiBasicScoreboardUI:GetTall() * 0.80)
		local ypos = 0.1
		for k, v in pairs(player.GetAll()) do
			local playerlist = vgui.Create("DPanel", scroll)
			playerlist:SetPos(70,ypos)
			playerlist:SetSize(830, 30)

			--Painting the original scroll bar 
			local sbar = scroll:GetVBar()
    		function sbar:Paint( w, h )
        		draw.RoundedBox(0, 0, 0, w, h, Color(95, 95, 95))
    		end
    		function sbar.btnUp:Paint( w, h )
        		draw.RoundedBox(0, 0, 0, w, h, Color(69, 69, 69))
    		end
    		function sbar.btnDown:Paint( w, h )
        		draw.RoundedBox(0, 0, 0, w, h, Color(69, 69, 69))
    		end
    		function sbar.btnGrip:Paint( w, h )
        		draw.RoundedBox(0, 0, 0, w, h, Color(69, 69, 69))
    		end

			--Local config to list variables on playerlist
			local name = v:Name()
			local job = v:getDarkRPVar("job")
			local teamCol = team.GetColor( v:Team())
			local ping = v:Ping()
			local rank = v:GetUserGroup()

			--Group configs for scoreboard
			local function TranslateGroup( v, c )
				if not c then
				if skibasicscoreboard.config.ranks[ v ] then
					return skibasicscoreboard.config.ranks[ v ].name
				else
					return 'User'
				end
				else
				if skibasicscoreboard.config.ranks[ v ] then
					return skibasicscoreboard.config.ranks[ v ].color
				else
					return Color( 255, 255, 255 )
				end
			end
		end
			
			--Avatar Image on playerlist
			local Avatar = vgui.Create( "AvatarImage", playerlist )
			Avatar:SetSize( 30, 30 )
			Avatar:SetPos( 0, 0 )
			Avatar:SetPlayer( v, 64 )

			--Playerlist info name,job,money,ping,rank
			playerlist.Paint = function(self, w, h)
				if IsValid(v) then
					local currency = skibasicscoreboard.config.currency
					local money = currency .. string.Comma(v:getDarkRPVar("money"))
					draw.SimpleText(money, "PlayerList", 690,3, Color(94, 255, 0), TEXT_ALIGN_CENTER)
					surface.SetDrawColor(31,31,31,168)
					surface.DrawRect(0,0,w,h)
					draw.SimpleText(name, "PlayerList", 100,3, Color(255,255,255), TEXT_ALIGN_CENTER)
					draw.SimpleText(job, "PlayerList", 280,3, (teamCol), TEXT_ALIGN_CENTER)
					draw.SimpleText(ping, "PlayerList", 790,3, Color(255,255,255), TEXT_ALIGN_CENTER)
					draw.SimpleText(TranslateGroup( v:GetUserGroup(), false ), "PlayerList", 495, 3, TranslateGroup( v:GetUserGroup(), true ), TEXT_ALIGN_CENTER )
				end
			end
			ypos = ypos + playerlist:GetTall() * 1.2
	end

--Closing the function
    else
		if IsValid(SkiBasicScoreboardUI) then
			SkiBasicScoreboardUI:Remove()
		end
	end
end

--Remove and show scoreboard
hook.Add("ScoreboardShow", "SkiOpenScoreboard", function()
	ToggleScoreboard(true)
	return false
end)

hook.Add("ScoreboardHide", "SkiHideScoreboard", function()
	ToggleScoreboard(false)
end)

--Fonts
surface.CreateFont( "ServerName", {font = "Circular Std Bold",extended = false,size = 60,antialias = true, weight = 1000, underline = false, shadow = false} )
surface.CreateFont( "Categories", {font = "Circular Std Bold",extended = false,size = 20,antialias = true, weight = 1000, underline = true, shadow = false} )
surface.CreateFont( "PlayersOnline", {font = "Circular Std Bold",extended = false,size = 20,antialias = true, weight = 1000, underline = false, shadow = true} )
surface.CreateFont( "PlayerList", {font = "Circular Std Bold",extended = false,size = 20,antialias = true, weight = 1000} )