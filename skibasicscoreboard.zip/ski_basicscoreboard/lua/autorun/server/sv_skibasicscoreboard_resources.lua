if (SERVER) then
    AddCSLuaFile("autorun/client/cl_skibasicscoreboard.lua")
    AddCSLuaFile("autorun/ski_basicscoreboard_config.lua")
    AddCSLuaFile("autorun/server/sv_skibasicscoreboard_resources.lua")

    resource.AddFile( "resource/fonts/circular_bold.ttf" )

end


